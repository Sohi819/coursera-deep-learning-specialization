function Get-Hello {
    param (
        [string]$Name = "World"
    )
    "Hello, $Name!"
}

function Get-CurrentTime {
    Get-Date
}